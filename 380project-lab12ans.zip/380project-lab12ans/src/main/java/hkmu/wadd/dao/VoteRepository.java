package hkmu.wadd.dao;
import hkmu.wadd.model.LectureUser;
import hkmu.wadd.model.Vote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface VoteRepository extends JpaRepository<Vote, Long> {
    @Query("SELECT v FROM Vote v WHERE v.poll.id = :pollId AND v.user = :user")
    Optional<Vote> findByPollAndUser(
            @Param("pollId") Long pollId,
            @Param("user") LectureUser user
    );
    List<Vote> findByUser(LectureUser user);
}