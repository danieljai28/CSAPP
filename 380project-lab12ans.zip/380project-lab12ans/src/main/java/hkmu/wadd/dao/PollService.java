package hkmu.wadd.dao;

import hkmu.wadd.exception.PollNotFound;
import hkmu.wadd.model.*;
import jakarta.transaction.Transactional;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PollService {

    @Autowired
    private PollRepository pollRepo;
    @Autowired
    private PollOptionRepository optionRepo;
    @Autowired
    private VoteRepository voteRepo;

    @Transactional
    public Poll createPoll(String question, String[] options, LectureUser user) {
        Poll poll = new Poll();
        poll.setQuestion(question);
        poll.setCreatedBy(user);
        for (String opt : options) {
            PollOption option = new PollOption();
            option.setOptionText(opt);
            option.setPoll(poll);
            poll.getOptions().add(option);
        }
        return pollRepo.save(poll);
    }

    @Transactional
    public void deletePoll(Long pollId) {
        pollRepo.deleteById(pollId);
    }

    @Transactional
    public void submitVote(Long pollId, Long optionId, LectureUser user) {
        PollOption option = optionRepo.findById(optionId).orElseThrow();
        option.setVotes(option.getVotes() + 1);
        optionRepo.save(option);

        Vote vote = new Vote();
        vote.setUser(user);
        vote.setPoll(option.getPoll());
        vote.setSelectedOption(option);
        voteRepo.save(vote);
    }
    @Transactional
    public Poll getPollById(Long pollId) throws PollNotFound {
        Poll poll = pollRepo.findById(pollId)
                .orElseThrow(() -> new PollNotFound(pollId));
        Hibernate.initialize(poll.getOptions());
        return poll;
    }

    public Vote getUserVote(Long pollId, LectureUser user) {
        return voteRepo.findByPollAndUser(pollId, user).orElse(null);
    }
    public List<Vote> getVotingHistory(LectureUser user) {
        return voteRepo.findByUser(user);
    }
    public List<Poll> getAllPolls() {
        return pollRepo.findAll();
    }
}