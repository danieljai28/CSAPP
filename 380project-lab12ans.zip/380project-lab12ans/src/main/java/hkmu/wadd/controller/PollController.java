package hkmu.wadd.controller;

import hkmu.wadd.dao.LectureUserService;
import hkmu.wadd.dao.PollService;
import hkmu.wadd.exception.PollNotFound;
import hkmu.wadd.model.LectureUser;
import hkmu.wadd.model.Poll;
import hkmu.wadd.model.Vote;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;

@Controller
@RequestMapping("/poll")
public class PollController {

    @Autowired
    private PollService pollService;

    @Autowired
    private LectureUserService userService;

    // Inner class for form data binding
    public static class PollForm {
        private String question;
        private String[] options = new String[4]; // Exactly 4 options

        public String getQuestion() { return question; }
        public void setQuestion(String question) { this.question = question; }
        public String[] getOptions() { return options; }
        public void setOptions(String[] options) { this.options = options; }
    }

    @GetMapping("/create")
    public String createPollForm(Model model) {
        model.addAttribute("pollForm", new PollForm());
        return "create-poll";
    }

    @PostMapping("/create")
    public String createPoll(@ModelAttribute PollForm form, Principal principal) {
        LectureUser user = userService.loadUserByUsername(principal.getName());
        pollService.createPoll(form.getQuestion(), form.getOptions(), user);
        return "redirect:/lecture/list";
    }

    @PostMapping("/vote/{pollId}/{optionId}")
    public String submitVote(
            @PathVariable Long pollId,
            @PathVariable Long optionId,
            Principal principal,
            HttpServletRequest request
    ) {
        LectureUser user = userService.loadUserByUsername(principal.getName());
        pollService.submitVote(pollId, optionId, user);
        return "redirect:" + request.getHeader("Referer"); // Redirect back to previous page
    }

    @GetMapping("/history")
    public String votingHistory(Principal principal, Model model) {
        LectureUser user = userService.loadUserByUsername(principal.getName());
        model.addAttribute("votes", pollService.getVotingHistory(user));
        return "vote-history";
    }

    @Transactional
    @GetMapping("/view/{pollId}")
    public String viewPoll(@PathVariable Long pollId, Model model, Principal principal) throws PollNotFound {
        Poll poll = pollService.getPollById(pollId);
        model.addAttribute("poll", poll);
        LectureUser user = userService.loadUserByUsername(principal.getName());
        Vote userVote = pollService.getUserVote(pollId, user);
        model.addAttribute("userVote", userVote);

        return "view-poll"; // Ensure this JSP exists
    }
    @GetMapping("/delete/{pollId}")
    public String deletePoll(@PathVariable Long pollId) {
        pollService.deletePoll(pollId);
        return "redirect:/lecture/list";
    }
    @ExceptionHandler(PollNotFound.class)
    public ModelAndView handlePollNotFound(PollNotFound e) {
        ModelAndView mav = new ModelAndView("error");
        mav.addObject("message", e.getMessage());
        return mav;
    }
}